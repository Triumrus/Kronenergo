<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', 'u0533063_kron');

/** Имя пользователя MySQL */
define('DB_USER', 'u0533063_kron');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', '}P(+wj~$({zS');

/** Имя сервера MySQL */
define('DB_HOST', 'localhost');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8mb4');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'cIEy.~;JsJO+?Nf/0M^ciiy[wj!QtG;xR6:GC&8V|+UhO@856u<ac4RS/Zp5Cjh^');
define('SECURE_AUTH_KEY',  'V}s=PD|g;[pHvVA1`n.#p|RfJ--BFyQoGbr&W[3n@M$35MB>xuSrmFJ`JS%9{*/[');
define('LOGGED_IN_KEY',    'wY:H%00.,8/dkf-92.7&}TjD;UPh.xZWXTRK`QT3uP?Y1OD*vSudBF9i)A$^wk!=');
define('NONCE_KEY',        'r8)^XUN#GDTb@dDqA^>aYLdOrV][/UV!00f2dkJ7/Vk,|z,tPDe@bQc`#ZW_0Ai*');
define('AUTH_SALT',        'P8wW]0HkTIn(}~)B$Olx17V;n%l>C&`rJ>Z<zpjUi@~e Be=3O1T{x?>hIAUUov~');
define('SECURE_AUTH_SALT', 'Y&81TW&TU!JJg .u#@;7rUJ_7;W9@$gLGddHu^G9OEY.:mzI5UKF~KuJ8>s4Dk*3');
define('LOGGED_IN_SALT',   'OcxswA@s3k)%SmkyEv&U.-qq?v/>3IIt-d }:n# <a>U;=qnV>?MJwFIq+M&]@oT');
define('NONCE_SALT',       '8:*a>ROU6/WESaa7-|Y,.?o9ya{ U~u,MD`>| 5GEU#r9R$Dy9g%NfQ/O4@1g `g');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
